using UnityEngine;
using UnityEngine.InputSystem; // Mantenha se estiver usando o Input System no Core
using Echo.Core;

namespace Echo.Gameplay
{
    public class EchoPlayerController : EchoActor
    {
        // Removemos refer�ncias ao CombatController aqui.
        // O Core n�o precisa saber como o combate funciona.

        protected override void Start()
        {
            base.Start();
        }

        private void Update()
        {
            if (isDead || Time.timeScale == 0) return;

            // Mant�m apenas a l�gica de Movimento
            HandleMovement();
        }

        private void HandleMovement()
        {
            float x = Input.GetAxisRaw("Horizontal");
            float y = Input.GetAxisRaw("Vertical");
            Move(new Vector2(x, y).normalized);
        }
    }
}