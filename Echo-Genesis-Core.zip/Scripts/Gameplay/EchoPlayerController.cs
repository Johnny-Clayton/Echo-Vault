using Echo.Core;
using UnityEngine;
using UnityEngine.InputSystem; 

namespace Echo.Gameplay
{
    public class EchoPlayerController : EchoActor
    {
        private const string DEFAULT_STATS_PATH = "PlayerStats";

        protected override void Start()
        {
            if (stats == null)
            {
                stats = Resources.Load<EntityStats>(DEFAULT_STATS_PATH);
                if (stats == null) Debug.LogError("[EchoPlayer] CR�TICO: N�o encontrei 'PlayerStats' na pasta Resources!");
            }
            base.Start();
        }

        private void Update()
        {
            if (isDead) return;

            Vector2 moveInput = Vector2.zero;

            // --- L�GICA DO NOVO INPUT SYSTEM (Direta) ---

            // 1. Verifica��o do Teclado (WASD + Setas)
            if (Keyboard.current != null)
            {
                if (Keyboard.current.wKey.isPressed || Keyboard.current.upArrowKey.isPressed)
                    moveInput.y += 1;

                if (Keyboard.current.sKey.isPressed || Keyboard.current.downArrowKey.isPressed)
                    moveInput.y -= 1;

                if (Keyboard.current.aKey.isPressed || Keyboard.current.leftArrowKey.isPressed)
                    moveInput.x -= 1;

                if (Keyboard.current.dKey.isPressed || Keyboard.current.rightArrowKey.isPressed)
                    moveInput.x += 1;
            }

            // 2. Verifica��o do Gamepad (Anal�gico Esquerdo)
            if (Gamepad.current != null)
            {
                // ReadValue j� retorna um Vector2 normalizado do anal�gico
                Vector2 gamepadInput = Gamepad.current.leftStick.ReadValue();

                // Se houver input no controle, ele sobrescreve o teclado
                if (gamepadInput.magnitude > 0.1f)
                {
                    moveInput = gamepadInput;
                }
            }

            // Move usando o Vector2 resultante
            Move(moveInput.normalized);
        }

        private void Reset()
        {
            stats = Resources.Load<EntityStats>(DEFAULT_STATS_PATH);
            var rb = GetComponent<Rigidbody2D>();
            if (rb)
            {
                rb.gravityScale = 0;
                rb.constraints = RigidbodyConstraints2D.FreezeRotation;
            }
        }

        public override void Die()
        {
            base.Die();
            Debug.Log("GAME OVER");
        }
    }
}