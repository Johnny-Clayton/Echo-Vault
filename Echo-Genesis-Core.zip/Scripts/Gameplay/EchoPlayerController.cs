using UnityEngine;
using System.Collections.Generic;
using Echo.Core;
using Echo.Combat; // Agora isso vai funcionar porque deletamos os .asmdef

namespace Echo.Gameplay
{
    public class EchoPlayerController : EchoActor
    {
        private CombatController combat;

        [Header("Configura��o de Combate")]
        // Lista de teclas para os Slots (0 = Espa�o, 1 = E, etc)
        public List<KeyCode> skillHotkeys = new List<KeyCode>()
        {
            KeyCode.Space,
            KeyCode.E,
            KeyCode.R
        };

        protected override void Start()
        {
            base.Start();
            combat = GetComponent<CombatController>();

            if (combat == null) Debug.LogWarning("CombatController n�o encontrado no Player!");
        }

        private void Update()
        {
            if (isDead || Time.timeScale == 0) return;

            HandleMovement();
            HandleCombat();
        }

        private void HandleMovement()
        {
            float x = Input.GetAxisRaw("Horizontal");
            float y = Input.GetAxisRaw("Vertical");
            Move(new Vector2(x, y).normalized);
        }

        private void HandleCombat()
        {
            if (combat == null) return;

            // Slot 0 tamb�m no Mouse (Padr�o RPG)
            if (Input.GetMouseButtonDown(0))
            {
                combat.UseSkillSlot(0);
            }

            // Checa todas as teclas da lista
            for (int i = 0; i < skillHotkeys.Count; i++)
            {
                if (Input.GetKeyDown(skillHotkeys[i]))
                {
                    combat.UseSkillSlot(i);
                }
            }
        }
    }
}