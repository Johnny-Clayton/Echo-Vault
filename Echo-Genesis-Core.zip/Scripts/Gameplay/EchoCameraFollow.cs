﻿using UnityEngine;
using Echo.Gameplay;

namespace Echo.Gameplay
{
    public class EchoCameraFollow : MonoBehaviour
    {
        public Transform target;
        public float smoothSpeed = 0.125f;
        public Vector3 offset = new Vector3(0, 0, -10);
        public SpriteRenderer mapLimits;

        private Camera cam;
        private float camHeight, camWidth;

        private void Start()
        {
            cam = GetComponent<Camera>();
            // Tenta achar o Ground logo de cara
            if (mapLimits == null)
            {
                GameObject groundObj = GameObject.Find("Ground");
                if (groundObj != null) mapLimits = groundObj.GetComponent<SpriteRenderer>();
            }
        }

        private void LateUpdate()
        {
            // --- BLOCO DE BUSCA CONSTANTE ---
            // Se não tem alvo, procura AGORA.
            if (target == null)
            {
                FindPlayer();
                return; // Se não achou, espera o próximo frame
            }
            // --------------------------------

            Vector3 desiredPosition = target.position + offset;

            // Lógica do Limite (Só executa se tiver mapa)
            if (mapLimits != null)
            {
                camHeight = cam.orthographicSize;
                camWidth = cam.aspect * camHeight;

                Bounds mapBounds = mapLimits.bounds;

                // Verifica se o mapa é grande o suficiente para travar a câmera
                if (mapBounds.size.x > camWidth * 2 && mapBounds.size.y > camHeight * 2)
                {
                    float minX = mapBounds.min.x + camWidth;
                    float maxX = mapBounds.max.x - camWidth;
                    float minY = mapBounds.min.y + camHeight;
                    float maxY = mapBounds.max.y - camHeight;

                    desiredPosition.x = Mathf.Clamp(desiredPosition.x, minX, maxX);
                    desiredPosition.y = Mathf.Clamp(desiredPosition.y, minY, maxY);
                }
            }

            // Garante que o Z seja sempre -10 para não sumir
            desiredPosition.z = -10;

            transform.position = Vector3.Lerp(transform.position, desiredPosition, smoothSpeed);
        }

        void FindPlayer()
        {
            // Tenta achar pelo script (EchoPlayerController)
            var playerScript = FindFirstObjectByType<EchoPlayerController>();
            if (playerScript != null)
            {
                target = playerScript.transform;
                return;
            }

            // Tenta achar pela Tag
            var playerObj = GameObject.FindGameObjectWithTag("Player");
            if (playerObj != null)
            {
                target = playerObj.transform;
            }
        }
    }
}