using UnityEngine;

namespace Echo.Gameplay
{
    public class EchoCameraFollow : MonoBehaviour
    {
        public Transform target;
        public float smoothSpeed = 0.125f;

        // Configura��o padr�o para TopDown 2D (Z = -10 � padr�o do Unity 2D)
        public Vector3 offset = new Vector3(0, 0, -10);

        private void Start()
        {
            if (target == null)
            {
                GameObject player = GameObject.FindGameObjectWithTag("Player");
                if (player != null) target = player.transform;
            }
        }

        private void LateUpdate()
        {
            if (target == null) return;

            Vector3 desiredPosition = target.position + offset;
            // Mant�m o Z fixo da c�mera para n�o sumir o mundo
            desiredPosition.z = transform.position.z;

            Vector3 smoothedPosition = Vector3.Lerp(transform.position, desiredPosition, smoothSpeed);
            transform.position = smoothedPosition;
        }
    }
}