using Echo.Core;
using UnityEngine;

namespace Echo.Gameplay
{
    public class EchoEnemyAI : EchoActor
    {
        private const string DEFAULT_STATS_PATH = "EnemyStats";

        [Header("AI Config")]
        [SerializeField] private float stopDistance = 0.6f;
        private Transform target;

        protected override void Start()
        {
            // 1. Auto-Load Stats
            if (stats == null)
            {
                stats = Resources.Load<EntityStats>(DEFAULT_STATS_PATH);
            }

            base.Start();

            // 2. Auto-Find Player
            GameObject player = GameObject.FindGameObjectWithTag("Player");
            if (player != null)
            {
                target = player.transform;
            }
            else
            {
                // Tenta achar pelo componente se a tag falhar
                var playerScript = FindFirstObjectByType<EchoPlayerController>();
                if (playerScript) target = playerScript.transform;
            }
        }

        private void FixedUpdate()
        {
            if (target == null || isDead)
            {
                Move(Vector2.zero);
                return;
            }

            float dist = Vector2.Distance(transform.position, target.position);

            // S� persegue se estiver no raio de detec��o (definido no Stats)
            if (dist < stats.detectionRadius && dist > stopDistance)
            {
                Vector2 dir = (target.position - transform.position).normalized;
                Move(dir);
            }
            else
            {
                Move(Vector2.zero);
            }
        }

        private void OnCollisionStay2D(Collision2D collision)
        {
            // Dano simples ao encostar
            if (collision.gameObject.CompareTag("Player"))
            {
                var damageable = collision.gameObject.GetComponent<IDamageable>();
                damageable?.TakeDamage(stats.baseDamage * Time.deltaTime);
            }
        }

        private void Reset()
        {
            stats = Resources.Load<EntityStats>(DEFAULT_STATS_PATH);
            var rb = GetComponent<Rigidbody2D>();
            if (rb)
            {
                rb.gravityScale = 0;
                rb.constraints = RigidbodyConstraints2D.FreezeRotation;
            }
        }
    }
}