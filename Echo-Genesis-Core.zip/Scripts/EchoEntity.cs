using UnityEngine;
using UnityEngine.Events;

namespace Echo.Core
{
    public abstract class EchoEntity : MonoBehaviour, IDamageable
    {
        [Header("Genesis Configuration")]
        [SerializeField] protected int maxHealth = 100;
        public int CurrentHealth { get; protected set; }
        public bool IsAlive => CurrentHealth > 0;

        [Header("Events")]
        public UnityEvent<int> OnDamageTaken;
        public UnityEvent OnDeath;

        protected virtual void Awake()
        {
            CurrentHealth = maxHealth;
        }

        public virtual void TakeDamage(int amount, Vector3 hitPoint)
        {
            if (!IsAlive) return;
            CurrentHealth = Mathf.Max(0, CurrentHealth - amount);
            OnDamageTaken?.Invoke(amount);
            if (CurrentHealth <= 0) Die();
        }

        public virtual void Die()
        {
            Debug.Log($"{gameObject.name} morreu.");
            OnDeath?.Invoke();
            Destroy(gameObject, 0.1f);
        }
    }
}