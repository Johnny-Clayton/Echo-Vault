using UnityEngine;
using UnityEngine.Events;

namespace Echo.Core
{
    /// <summary>
    /// Classe base absoluta para todos os seres vivos do jogo.
    /// Gerencia Ciclo de Vida, Sa�de e Eventos.
    /// </summary>
    public abstract class EchoEntity : MonoBehaviour, IDamageable
    {
        [Header("--- GENESIS CORE: CONFIG ---")]
        [SerializeField] protected EntityStats stats;

        [Header("--- DEBUG / STATE ---")]
        [SerializeField, ReadOnly] protected float currentHealth;
        [ReadOnly] protected bool isDead;

        public bool IsDead => isDead;

        // Eventos para desacoplamento (UI, Som, Part�culas)
        [Space(10)]
        public UnityEvent<float> OnHealthChanged;      // Passa a % de vida (0 a 1)
        public UnityEvent<float> OnDamageTaken;        // Passa o valor do dano
        public UnityEvent OnDeath;

        protected virtual void Start()
        {
            Initialize();
        }

        /// <summary>
        /// Reinicia a entidade para o estado definido no DNA (Stats).
        /// </summary>
        public virtual void Initialize()
        {
            if (stats == null)
            {
                Debug.LogError($"[ECHO CORE] CRITICAL: A entidade '{name}' n�o possui EntityStats atribu�do!", this);
                enabled = false;
                return;
            }

            currentHealth = stats.maxHealth;
            isDead = false;

            // Dispara evento inicial para atualizar UI
            OnHealthChanged?.Invoke(1f);
        }

        public virtual void TakeDamage(float amount)
        {
            if (isDead) return;

            currentHealth -= amount;

            // Invoca eventos
            OnDamageTaken?.Invoke(amount);
            OnHealthChanged?.Invoke(currentHealth / stats.maxHealth);

            if (currentHealth <= 0)
            {
                Die();
            }
        }

        public virtual void Die()
        {
            if (isDead) return;

            isDead = true;
            OnDeath?.Invoke();

            Debug.Log($"[ECHO] {name} ({(stats ? stats.entityName : "Entity")}) Morreu.");

            // Comportamento padr�o: Destruir o objeto.
            // Classes filhas (Player) devem sobrescrever isso para evitar Game Over abrupto.
            Destroy(gameObject, 0.1f);
        }

        // Getter �til para outras classes
        public EntityStats Stats => stats;
    }

    // Atributo auxiliar para deixar campos ReadOnly no Inspector (opcional, mas bom pra UX)
    public class ReadOnlyAttribute : PropertyAttribute { }
}