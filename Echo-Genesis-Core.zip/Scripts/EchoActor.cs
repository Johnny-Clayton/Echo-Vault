using UnityEngine;

namespace Echo.Core
{
    /// Entidade base com corpo físico e movimento 2D.
    /// Compatível com jogos TopDown ou Plataforma.
    /// Movimento baseado em Rigidbody2D (velocity).
    [RequireComponent(typeof(Rigidbody2D))]
    [RequireComponent(typeof(Collider2D))]
    public abstract class EchoActor : EchoEntity
    {
        protected Rigidbody2D rb;

        protected bool isFacingRight = true;
        protected Vector2 moveDirection;

        protected override void Start()
        {
            base.Start();

            rb = GetComponent<Rigidbody2D>();

            // Configuração física segura
            rb.gravityScale = 0f;
            rb.freezeRotation = true;
            rb.interpolation = RigidbodyInterpolation2D.Interpolate;
            rb.collisionDetectionMode = CollisionDetectionMode2D.Continuous;
        }

        /// Aplica movimento físico.
        /// Deve ser chamado SOMENTE no FixedUpdate.
        protected virtual void Move(Vector2 direction)
        {
            if (isDead || stats == null)
            {
                rb.linearVelocity = Vector2.zero;
                return;
            }

            rb.linearVelocity = direction * stats.moveSpeed;
            HandleSpriteFlip(direction.x);
        }

        /// Para o movimento imediatamente.
        protected virtual void StopMovement()
        {
            rb.linearVelocity = Vector2.zero;
        }

        /// Gerencia o flip do sprite baseado no movimento horizontal.
        protected virtual void HandleSpriteFlip(float horizontalMovement)
        {
            if (Mathf.Abs(horizontalMovement) < 0.01f)
                return;

            if (horizontalMovement > 0 && !isFacingRight)
                Flip();
            else if (horizontalMovement < 0 && isFacingRight)
                Flip();
        }

        /// Inverte a direção visual do personagem.
        protected virtual void Flip()
        {
            isFacingRight = !isFacingRight;

            Vector3 rotation = transform.eulerAngles;
            rotation.y += 180f;
            transform.eulerAngles = rotation;
        }

        /// Mata o ator e interrompe toda movimentação.
        public override void Die()
        {
            StopMovement();
            base.Die(); // usa o isDead da EchoEntity
        }

        protected bool IsMoving()
        {
            return rb.linearVelocity.sqrMagnitude > 0.01f;
        }
    }
}
