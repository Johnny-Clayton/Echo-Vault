using UnityEngine;

namespace Echo.Core
{
    /// <summary>
    /// Extens�o da Entidade que possui corpo f�sico e capacidade de locomo��o.
    /// Assume um jogo 2D (TopDown ou Plataforma).
    /// </summary>
    [RequireComponent(typeof(Rigidbody2D))]
    [RequireComponent(typeof(Collider2D))]
    public abstract class EchoActor : EchoEntity
    {
        protected Rigidbody2D rb;
        protected bool isFacingRight = true;
        protected Vector2 currentVelocity;

        protected override void Start()
        {
            base.Start();
            rb = GetComponent<Rigidbody2D>();

            // Configura��o padr�o de f�sica para evitar comportamentos estranhos
            rb.interpolation = RigidbodyInterpolation2D.Interpolate;
            rb.collisionDetectionMode = CollisionDetectionMode2D.Continuous;
        }

        /// <summary>
        /// Aplica movimento f�sico. Deve ser chamado no FixedUpdate.
        /// </summary>
        /// <param name="direction">Dire��o normalizada (Input)</param>
        protected virtual void Move(Vector2 direction)
        {
            if (isDead || stats == null)
            {
                rb.linearVelocity = Vector2.zero;
                return;
            }

            // Movimento simples via Velocity (pode ser trocado por AddForce para in�rcia)
            Vector2 targetVelocity = direction * stats.moveSpeed;
            rb.linearVelocity = targetVelocity;

            HandleSpriteFlip(direction.x);
        }

        /// <summary>
        /// Gerencia a dire��o do Sprite baseado no movimento horizontal.
        /// </summary>
        protected virtual void HandleSpriteFlip(float horizontalMovement)
        {
            if (Mathf.Abs(horizontalMovement) < 0.1f) return;

            if (horizontalMovement > 0 && !isFacingRight) Flip();
            else if (horizontalMovement < 0 && isFacingRight) Flip();
        }

        protected void Flip()
        {
            isFacingRight = !isFacingRight;

            // Rotacionar o transform � melhor que escalar negativamente (evita bugs com filhos)
            // Mas para 2D simples, escala funciona bem. Vamos usar rota��o Y para ser mais robusto.
            Vector3 rotator = transform.eulerAngles;
            rotator.y += 180f;
            transform.eulerAngles = rotator;
        }
    }
}