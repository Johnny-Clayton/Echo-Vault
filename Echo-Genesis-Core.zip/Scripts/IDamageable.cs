using UnityEngine;

namespace Echo.Core
{
    /// <summary>
    /// Interface universal para qualquer objeto que possa sofrer dano (Inimigos, Player, Caixas, Bosses).
    /// </summary>
    public interface IDamageable
    {
        void TakeDamage(float amount);
        void Die();

        // Opcional: Para saber de quem veio o dano (�til para kill feed)
        // void TakeDamage(float amount, GameObject source);
    }
}