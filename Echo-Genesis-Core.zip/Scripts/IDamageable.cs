using UnityEngine;

namespace Echo.Core
{
    public interface IDamageable
    {
        void TakeDamage(int amount, Vector3 hitPoint);
        void Die();
        bool IsAlive { get; }
    }
}