using UnityEngine;

namespace Echo.Core
{
    [CreateAssetMenu(fileName = "NewEntityStats", menuName = "ECHO/Core/Entity DNA", order = 0)]
    public class EntityStats : ScriptableObject
    {
        [Header("Survival Stats")]
        [Tooltip("Nome de exibi��o para UI")]
        public string entityName = "Unnamed Entity";
        public float maxHealth = 100f;

        [Header("Movement Stats")]
        public float moveSpeed = 5f;
        public float acceleration = 50f; // Para movimentos mais suaves

        [Header("Combat Stats")]
        public float baseDamage = 10f;
        public float attackRate = 1f; // Ataques por segundo
        public float attackRange = 1.5f;

        [Header("AI Configuration")]
        public float detectionRadius = 10f;
        public LayerMask targetLayers; // O que esta entidade considera 'inimigo'?
    }
}