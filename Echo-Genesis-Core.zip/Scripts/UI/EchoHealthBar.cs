using UnityEngine;
using UnityEngine.UI;
using Echo.Core;

namespace Echo.UI
{
    public class EchoHealthBar : MonoBehaviour
    {
        [Header("Configura��o")]
        [SerializeField] private Slider slider;
        [SerializeField] private EchoEntity entityToWatch;
        [SerializeField] private bool isFloatingBar = false;

        private void Start()
        {
            // Auto-detecta componentes se estiverem vazios
            if (slider == null) slider = GetComponentInChildren<Slider>();
            if (entityToWatch == null) entityToWatch = GetComponentInParent<EchoEntity>();

            if (entityToWatch != null)
            {
                // Limpa conex�es antigas e cria a nova
                entityToWatch.OnHealthChanged.RemoveListener(UpdateHealthUI);
                entityToWatch.OnHealthChanged.AddListener(UpdateHealthUI);

                // For�a a barra a encher no in�cio
                UpdateHealthUI(1f);
                Debug.Log($"[UI] Barra conectada ao: {entityToWatch.name}");
            }
            else
            {
                Debug.LogError("[UI CR�TICO] O campo 'Entity To Watch' est� vazio! Arraste o Player para c�.");
            }
        }

        public void UpdateHealthUI(float percentage)
        {
            if (slider == null) return;

            // --- A M�GICA DA CORRE��O DE ESCALA ---
            // Se o Slider estiver configurado para 100, transformamos 0.9 em 90.
            // Se estiver configurado para 1, mantemos 0.9.

            if (slider.maxValue > 1.1f) // Assumimos que � escala 0-100
            {
                slider.value = percentage * slider.maxValue;
                Debug.Log($"[UI] Vida: {percentage * 100}% (Valor Slider: {slider.value})");
            }
            else // Assumimos que � escala 0-1
            {
                slider.value = percentage;
                Debug.Log($"[UI] Vida: {percentage * 100}% (Valor Slider: {slider.value})");
            }
        }

        private void LateUpdate()
        {
            if (isFloatingBar)
            {
                transform.rotation = Quaternion.identity;
            }
        }
    }
}