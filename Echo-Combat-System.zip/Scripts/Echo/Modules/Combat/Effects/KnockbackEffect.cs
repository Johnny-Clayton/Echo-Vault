using UnityEngine;
using Echo.Core;   
using Echo.Combat;

namespace Echo.Combat.Effects
{
    using UnityEngine;

    [CreateAssetMenu(menuName = "ECHO/Combat/Effects/Knockback")]
    public class KnockbackEffect : AttackEffect
    {
        public float force = 5f;

        public override void Apply(EchoActor source, GameObject target)
        {
            Rigidbody2D rb = target.GetComponent<Rigidbody2D>();
            if (rb)
            {
                // Calcula dire��o do empurr�o (Source -> Target)
                Vector2 direction = (target.transform.position - source.transform.position).normalized;
                rb.AddForce(direction * force, ForceMode2D.Impulse);
            }
        }
    }
}