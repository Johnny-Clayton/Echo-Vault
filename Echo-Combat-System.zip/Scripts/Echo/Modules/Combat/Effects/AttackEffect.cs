using UnityEngine;
using Echo.Core;

namespace Echo.Combat
{
    public abstract class AttackEffect : ScriptableObject
    {
        public abstract void Apply(EchoActor source, GameObject target);
    }
}