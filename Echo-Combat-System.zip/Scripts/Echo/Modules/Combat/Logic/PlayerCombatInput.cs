using UnityEngine;
using System.Collections.Generic;
using Echo.Core; // Pega o estado do Actor (IsDead)

namespace Echo.Combat
{
    /// <summary>
    /// Este script serve de "ponte" entre o Teclado/Mouse e o CombatController.
    /// Ele vive no pacote de Combate, ent�o o Core n�o precisa conhec�-lo.
    /// </summary>
    [RequireComponent(typeof(CombatController))]
    public class PlayerCombatInput : MonoBehaviour
    {
        private CombatController combat;
        private EchoEntity entity; // Para checar se est� morto

        [Header("Mapeamento de Teclas")]
        [Tooltip("Bot�o para o Slot 0 (Geralmente Ataque B�sico)")]
        public KeyCode basicAttackKey = KeyCode.Space;
        public bool useMouseClick = true;

        [Tooltip("Teclas para Slots 1, 2, 3... (Skills)")]
        public List<KeyCode> skillHotkeys = new List<KeyCode>()
        {
            KeyCode.E,
            KeyCode.R,
            KeyCode.Q
        };

        private void Start()
        {
            combat = GetComponent<CombatController>();
            entity = GetComponent<EchoEntity>();
        }

        private void Update()
        {
            // Se estiver morto ou jogo pausado, n�o processa input
            if (entity != null && entity.IsDead) return;
            if (Time.timeScale == 0) return;

            HandleInputs();
        }

        private void HandleInputs()
        {
            // Slot 0: Espa�o ou Clique
            if (Input.GetKeyDown(basicAttackKey) || (useMouseClick && Input.GetMouseButtonDown(0)))
            {
                combat.UseSkillSlot(0);
            }

            // Outros Slots: Percorre a lista
            for (int i = 0; i < skillHotkeys.Count; i++)
            {
                // Slot 1 usa o elemento 0 da lista hotkeys, etc.
                if (Input.GetKeyDown(skillHotkeys[i]))
                {
                    // +1 porque o Slot 0 j� foi usado acima
                    combat.UseSkillSlot(i + 1);
                }
            }
        }
    }
}