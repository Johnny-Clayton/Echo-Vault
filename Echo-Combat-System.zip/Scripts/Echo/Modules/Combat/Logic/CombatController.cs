using System.Collections.Generic;
using UnityEngine;
using Echo.Core;

namespace Echo.Combat
{
    [RequireComponent(typeof(EchoActor))]
    public class CombatController : MonoBehaviour
    {
        [Header("Loadout (Habilidades Equipadas)")]
        // Array fixo para os bot�es (Ex: 0=B�sico, 1=Skill Q, 2=Skill E, 3=Ult)
        [Tooltip("Arraste os ataques iniciais aqui. Index 0 geralmente � o ataque b�sico.")]
        public AttackDefinition[] equippedSkills = new AttackDefinition[3];

        [Header("Invent�rio (Habilidades Aprendidas)")]
        [Tooltip("Lista de todas as habilidades que este personagem possui.")]
        public List<AttackDefinition> learnedSkills = new List<AttackDefinition>();

        private EchoActor actor;
        private Animator anim;

        // Dicion�rio de Cooldowns: Nome do Ataque -> Tempo que estar� pronto
        private Dictionary<string, float> cooldowns = new Dictionary<string, float>();

        private void Start()
        {
            actor = GetComponent<EchoActor>();
            anim = GetComponentInChildren<Animator>();

            // Inicializa��o segura: Garante que as skills equipadas est�o na lista de aprendidas
            foreach (var skill in equippedSkills)
            {
                if (skill != null && !learnedSkills.Contains(skill))
                {
                    learnedSkills.Add(skill);
                }
            }
        }

        /// <summary>
        /// Tenta usar a habilidade equipada no Slot espec�fico.
        /// (Ex: Slot 0 = Espa�o, Slot 1 = Tecla Q)
        /// </summary>
        public void UseSkillSlot(int slotIndex)
        {
            if (actor.IsDead) return;

            // Valida��o de Slot
            if (slotIndex < 0 || slotIndex >= equippedSkills.Length) return;

            AttackDefinition attack = equippedSkills[slotIndex];

            // Se o slot estiver vazio, n�o faz nada
            if (attack == null) return;

            // Verifica Cooldown
            if (cooldowns.ContainsKey(attack.attackName))
            {
                float readyTime = cooldowns[attack.attackName];
                if (Time.time < readyTime)
                {
                    // Est� em Cooldown (Aqui voc� pode tocar um som de "erro" ou piscar a UI)
                    return;
                }
            }

            ExecuteAttack(attack);
        }

        private void ExecuteAttack(AttackDefinition attack)
        {
            // 1. Registra Cooldown (Tempo Atual + Cooldown do Ataque)
            cooldowns[attack.attackName] = Time.time + attack.cooldown;

            // 2. Anima��o
            if (anim != null && !string.IsNullOrEmpty(attack.animationTrigger))
            {
                anim.SetTrigger(attack.animationTrigger);
            }

            // 3. Executa a L�gica (Pattern)
            if (attack.pattern != null)
            {
                attack.pattern.Execute(actor, attack);
            }
        }

        // --- SISTEMA DE LOJA E PROGRESS�O ---

        /// <summary>
        /// Chamado pela LOJA quando o player compra uma habilidade.
        /// </summary>
        public void LearnAttack(AttackDefinition newAttack)
        {
            if (!learnedSkills.Contains(newAttack))
            {
                learnedSkills.Add(newAttack);
                Debug.Log($"[EchoCombat] Nova habilidade aprendida: {newAttack.attackName}");

                // Opcional: Auto-equipar no primeiro slot vazio
                AutoEquip(newAttack);
            }
        }

        /// <summary>
        /// Chamado pelo MENU DE EQUIPAMENTO para mudar os bot�es.
        /// </summary>
        public void EquipAttack(AttackDefinition attack, int slotIndex)
        {
            if (slotIndex < 0 || slotIndex >= equippedSkills.Length) return;

            // S� pode equipar se j� aprendeu
            if (learnedSkills.Contains(attack))
            {
                equippedSkills[slotIndex] = attack;
                Debug.Log($"[EchoCombat] Equipado {attack.attackName} no Slot {slotIndex}");
            }
            else
            {
                Debug.LogError("Tentou equipar uma habilidade que o player n�o possui!");
            }
        }

        private void AutoEquip(AttackDefinition attack)
        {
            for (int i = 0; i < equippedSkills.Length; i++)
            {
                if (equippedSkills[i] == null)
                {
                    equippedSkills[i] = attack;
                    return;
                }
            }
        }

        // --- M�TODOS PARA UI (HUD) ---

        // Retorna 0 se pronto, ou a % restante do cooldown (�til para imagem de fill na UI)
        public float GetCooldownProgress(int slotIndex)
        {
            if (slotIndex >= equippedSkills.Length || equippedSkills[slotIndex] == null) return 0;

            var attack = equippedSkills[slotIndex];
            if (!cooldowns.ContainsKey(attack.attackName)) return 0;

            float readyTime = cooldowns[attack.attackName];
            float remaining = readyTime - Time.time;

            if (remaining <= 0) return 0;

            return Mathf.Clamp01(remaining / attack.cooldown);
        }
    }
}