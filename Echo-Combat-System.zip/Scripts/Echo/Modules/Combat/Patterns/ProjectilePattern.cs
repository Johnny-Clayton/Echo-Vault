using UnityEngine;
using Echo.Core;

namespace Echo.Combat.Patterns
{
    [CreateAssetMenu(menuName = "ECHO/Combat/Patterns/Projectile")]
    public class ProjectilePattern : AttackPattern
    {
        public GameObject projectilePrefab;
        public float projectileSpeed = 10f;

        public override void Execute(EchoActor attacker, AttackDefinition data)
        {
            // L�gica simples: Instancia o proj�til e passa os dados de dano para ele
            // O proj�til precisaria de seu pr�prio script para voar e colidir

            // Exemplo conceitual:
            /*
            var proj = Instantiate(projectilePrefab, attacker.transform.position, attacker.transform.rotation);
            var script = proj.GetComponent<EchoProjectile>();
            float dmg = CalculateFinalDamage(attacker, data);
            script.Initialize(dir: attacker.transform.right, speed: projectileSpeed, damage: dmg, layers: targetLayers);
            */
            Debug.Log("Disparou proj�til! (Implementar script do proj�til)");
        }
    }
}