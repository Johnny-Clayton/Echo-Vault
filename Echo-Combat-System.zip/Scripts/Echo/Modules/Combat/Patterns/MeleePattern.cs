using UnityEngine;
using Echo.Core;

namespace Echo.Combat.Patterns
{
    [CreateAssetMenu(menuName = "ECHO/Combat/Patterns/Melee (OverlapCircle)")]
    public class MeleePattern : AttackPattern
    {
        public override void Execute(EchoActor attacker, AttackDefinition data)
        {
            // Ponto de origem (usa o transform do atacante)
            Vector3 origin = attacker.transform.position;

            // Detecta colisores na �rea
            Collider2D[] hits = Physics2D.OverlapCircleAll(origin, range, targetLayers);

            foreach (var hit in hits)
            {
                if (hit.gameObject == attacker.gameObject) continue; // Ignora a si mesmo

                IDamageable target = hit.GetComponent<IDamageable>();
                if (target != null)
                {
                    // 1. Aplica Dano
                    float finalDamage = CalculateFinalDamage(attacker, data);
                    target.TakeDamage(finalDamage);

                    // 2. Aplica Efeitos Extras (Knockback, etc)
                    if (data.effects != null)
                    {
                        foreach (var effect in data.effects)
                        {
                            effect.Apply(attacker, hit.gameObject);
                        }
                    }
                }
            }

            // 3. Efeitos Visuais e Sonoros
            if (data.vfxPrefab) Instantiate(data.vfxPrefab, origin, Quaternion.identity);
            if (data.sfx) AudioSource.PlayClipAtPoint(data.sfx, origin);
        }

        public override void DrawGizmos(Transform attacker)
        {
            Gizmos.color = Color.red;
            Gizmos.DrawWireSphere(attacker.position, range);
        }
    }
}