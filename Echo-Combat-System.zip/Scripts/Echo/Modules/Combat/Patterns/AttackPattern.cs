using UnityEngine;
using Echo.Core; // Necess�rio para acessar EchoActor

namespace Echo.Combat
{
    public abstract class AttackPattern : ScriptableObject
    {
        [Header("Configura��es do Padr�o")]
        public float range = 1.5f;
        public LayerMask targetLayers;

        /// <summary>
        /// M�todo que executa a l�gica do ataque.
        /// </summary>
        /// <param name="attacker">Quem est� atacando (Player/Enemy)</param>
        /// <param name="data">Os dados do ataque (Dano, VFX, etc)</param>
        public abstract void Execute(EchoActor attacker, AttackDefinition data);

        /// <summary>
        /// Utilit�rio para calcular dano final (Base + Stats + Cr�tico)
        /// </summary>
        protected float CalculateFinalDamage(EchoActor attacker, AttackDefinition data)
        {
            float damage = data.baseDamage;

            // Soma com o dano base da entidade (se existir stats)
            if (data.addEntityBaseDamage && attacker.Stats != null)
            {
                damage += attacker.Stats.baseDamage;
            }

            // Cr�tico
            if (Random.value <= data.criticalChance)
            {
                damage *= data.criticalMultiplier;
                Debug.Log($"[EchoCombat] CR�TICO! ({damage})");
            }

            return damage;
        }

        // Para desenhar Gizmos no Editor (Opcional, mas �til)
        public virtual void DrawGizmos(Transform attacker) { }
    }
}