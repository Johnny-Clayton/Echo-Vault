using UnityEngine;

namespace Echo.Combat
{
    [CreateAssetMenu(menuName = "ECHO/Combat/New Attack Definition", fileName = "NewAttack")]
    public class AttackDefinition : ScriptableObject
    {
        [Header("Identidade")]
        public string attackName;
        [TextArea] public string description;
        public Sprite icon;

        [Header("Configura��o de Execu��o")]
        public AttackPattern pattern; // A estrat�gia (Como ele ataca?)
        public float cooldown = 0.5f;
        public float resourceCost = 0f; // Ex: Stamina/Mana

        [Header("Dano")]
        public float baseDamage = 10f;
        [Tooltip("Se marcado, soma com o Dano Base dos Stats da entidade")]
        public bool addEntityBaseDamage = true;
        [Range(0f, 1f)] public float criticalChance = 0.05f;
        public float criticalMultiplier = 1.5f;

        [Header("Visual & Audio")]
        public string animationTrigger = "Attack";
        public GameObject vfxPrefab;
        public AudioClip sfx;

        [Header("Efeitos Adicionais")]
        public AttackEffect[] effects; // Ex: Knockback, Stun, Burn
    }
}