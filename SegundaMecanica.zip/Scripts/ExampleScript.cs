using UnityEngine;

namespace MyGame.Mechanics
{
    public class ExampleScript : MonoBehaviour
    {
    }
}