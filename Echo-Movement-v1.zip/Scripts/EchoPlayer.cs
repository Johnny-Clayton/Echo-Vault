using UnityEngine;
using Echo.Core; // Importando o Core que baixamos antes

namespace Echo.Gameplay.Player
{
    // Herda de EchoEntity, ganhando automaticamente Health, Die(), TakeDamage()...
    public class EchoPlayer : EchoEntity
    {
        [Header("Player Stats")]
        [SerializeField] private float stamina = 100f;
        [SerializeField] private float mana = 50f;

        // Sobrescrevemos o m�todo de morte para fazer algo espec�fico do Player
        public override void Die()
        {
            Debug.Log("GAME OVER - O Player morreu!");
            base.OnDeath?.Invoke();
            // Aqui voc� poderia chamar uma tela de Game Over, respawn, etc.
            // Note que N�O chamamos base.Die() para n�o destruir o objeto do Player.
        }
    }
}