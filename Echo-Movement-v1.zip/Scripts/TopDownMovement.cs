using UnityEngine;
using UnityEngine.InputSystem;

namespace Echo.Gameplay.Player
{
    [RequireComponent(typeof(Rigidbody2D))]
    public class TopDownMovement : MonoBehaviour
    {
        [Header("Settings")]
        [SerializeField] private float moveSpeed = 5f;

        private Vector2 moveInput;
        private Rigidbody2D rb;
        private Animator anim;

        private void Awake()
        {
            rb = GetComponent<Rigidbody2D>();
            anim = GetComponentInChildren<Animator>();

            // Configura��o autom�tica de f�sica para TopDown
            rb.gravityScale = 0;
            rb.freezeRotation = true;
            rb.collisionDetectionMode = CollisionDetectionMode2D.Continuous;
        }

        // M�todo chamado pelo Unity Input System (SendMessages)
        public void OnMove(InputValue value)
        {
            moveInput = value.Get<Vector2>();
        }

        private void FixedUpdate()
        {
            rb.linearVelocity = moveInput * moveSpeed;

            // Anima��o Simples
            if (anim != null)
            {
                bool isMoving = moveInput.sqrMagnitude > 0.1f;
                anim.SetBool("IsMoving", isMoving);
                if (isMoving)
                {
                    anim.SetFloat("InputX", moveInput.x);
                    anim.SetFloat("InputY", moveInput.y);
                }
            }
        }
    }
}