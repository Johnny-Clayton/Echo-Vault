using UnityEngine;
using UnityEngine.InputSystem; // Depend�ncia Importante

namespace Echo.Gameplay
{
    [RequireComponent(typeof(Rigidbody2D))]
    public class TopDownController : MonoBehaviour
    {
        [Header("Settings")]
        [SerializeField] private float moveSpeed = 5f;

        [Header("Info (Read Only)")]
        [SerializeField] private Vector2 currentInput;
        [SerializeField] private bool isMoving;

        private Rigidbody2D rb;
        private Animator anim;

        private void Awake()
        {
            rb = GetComponent<Rigidbody2D>();
            anim = GetComponentInChildren<Animator>();

            // Configura��es F�sicas Ideais para Top-Down
            rb.gravityScale = 0;
            rb.collisionDetectionMode = CollisionDetectionMode2D.Continuous;
            rb.freezeRotation = true;
        }

        // Chamado pelo PlayerInput (New Input System)
        public void OnMove(InputValue value)
        {
            currentInput = value.Get<Vector2>();
        }

        private void FixedUpdate()
        {
            // Movimento F�sico (N�o atravessa paredes)
            rb.linearVelocity = currentInput * moveSpeed;
            isMoving = currentInput.sqrMagnitude > 0.1f;

            HandleAnimation();
        }

        private void HandleAnimation()
        {
            if (anim == null) return;

            anim.SetBool("IsMoving", isMoving);

            if (isMoving)
            {
                anim.SetFloat("InputX", currentInput.x);
                anim.SetFloat("InputY", currentInput.y);
            }
        }
    }
}